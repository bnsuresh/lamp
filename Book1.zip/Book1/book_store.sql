-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2018 at 07:53 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(25) NOT NULL,
  `unm` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `unm`, `pwd`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `b_id` int(4) NOT NULL,
  `b_nm` varchar(60) NOT NULL,
  `b_subcat` varchar(25) NOT NULL,
  `b_desc` longtext NOT NULL,
  `b_publisher` varchar(40) NOT NULL,
  `b_edition` varchar(20) NOT NULL,
  `b_isbn` varchar(10) NOT NULL,
  `b_page` int(5) NOT NULL,
  `b_price` int(5) NOT NULL,
  `b_img` longtext NOT NULL,
  `b_pdf` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`b_id`, `b_nm`, `b_subcat`, `b_desc`, `b_publisher`, `b_edition`, `b_isbn`, `b_page`, `b_price`, `b_img`, `b_pdf`) VALUES
(55, 'ethd', '43', 'sfgzdthd', 'sdth', '4', '5', 56, 616, 'upload_image/adapter design.jpg', 'upload_ebook/rust.pdf'),
(53, 'ooad', '38', 'jdshfB', 'DSSD', '2', '66', 654, 5000, 'upload_image/IMG_0194.JPG', 'upload_ebook/teja epass.pdf'),
(54, 'aoa', '38', 'rger', 'gaerg', '5', '3546', 546, 654, 'upload_image/krutz.jpg', 'upload_ebook/teja epass.pdf'),
(56, 'ood1', '38', 'rserys', 'dgzzdg', '5', '66', 55, 5565, 'upload_image/download (1).jpg', 'upload_ebook/j IA1.pdf'),
(58, 'reg', '42', 'wg', 'erg', '3', '23454', 235, 235, 'upload_image/use case4.jpg', 'upload_ebook/rust.pdf'),
(49, 'PAKISTAN`S DRIFT INTO EXTREMISM', '13', 'The book studies the rise of religious extremism in pakistan and analyses its connection to the pakistani army policies and fluctuating US - Pakistani Relationship. It is a book which readers as well as students of Political Science and history will enjoy thoroughly.', 'Hassan Abbas ', '2001', '8182741580', 350, 600, 'upload_image/terr2.jpg', 'upload_ebook/terror1.txt'),
(50, 'Learning SQL on SQL Server 2005 : The Simplest Way', '18', 'Anyone who interacts with today?s modern databases needs to know SQL (Structured Query Language), the standard language for generating, manipulating, and retrieving database information. In recent years, the dramatic rise in the popularity of relational databases and multiuser databases has fueled a healthy demand for application devel?opers and others who can write SQL code efficiently and correctly. If you?re new to databases or need a SQL refresher, Learning SQL on SQL Server 2005 is an ideal step-by-step introduction to this database query tool, with everything you need for programming SQL using Microsoft?s SQL Server 2005?one of the most powerful and popular database engines used today. Plenty of books explain database theory. This guide lets you apply the theory as you learn SQL. You don?t need prior database knowledge, or even prior computer knowledge. Based on a popular university-level course designed by authors Sikha Saha Bagui and Richard Walsh Earp, Learning SQL on SQL Server 2005 starts with very simple SQL concepts, and slowly builds into more complex query development. Every topic, concept, and idea comes with examples of code and output, along with exercises to help you gain proficiency in SQL and SQL Server 2005. With this book, you?ll learn: * Beginning SQL commands, such as how and where to type an SQL query, and how to create, populate, alter, and delete tables * How to customize SQL Server 2005?s settings and about SQL Server 2005?s functions * About joins, a common database mechanism for combining tables * Query development, the use of views and other derived structures, and simple set operations * Subqueries, aggregate functions, and correlated subqueries, as well as indexes and constraints that can be added to tables in SQL Server 2005 Whether you?re a self-learner who has access to the new Microsoft database, working on SQL Server with access at your company, or a computer science student or MIS student, Learning SQL on SQL Server 2005 will get you up to speed on SQL in no time.\r\n\r\n', 'Sikha Saha Bagui, Richard Walsh Earp ', '2005', '9788184040', 360, 350, 'upload_image/comp10.jpg', 'upload_ebook/sql1.docx');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(4) NOT NULL,
  `cat_nm` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_nm`) VALUES
(29, 'electronics and communication '),
(28, 'mechanical engg'),
(27, 'civil engg'),
(26, 'information science engg'),
(25, 'electrical and electronics eng'),
(24, 'computer science and engg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `con_id` int(4) NOT NULL,
  `con_nm` varchar(25) NOT NULL,
  `con_email` varchar(35) NOT NULL,
  `con_query` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`con_id`, `con_nm`, `con_email`, `con_query`) VALUES
(1, 'Hiren', 'hiru@gmail.com', 'English Novels...'),
(2, 'Shital', 'shital@yahoo.com', 'Are you send me medical books?'),
(3, 'Manali', 'manali@yahoo.com', 'Java Complete Reference is available?'),
(4, 'Rina', 'rina@gmail.com', 'Artificial Intelligence'),
(5, 'diganth', 'diganthbr55@gmail.com', 'dfsfsdsvv');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_details`
--

CREATE TABLE `shipping_details` (
  `id` int(11) NOT NULL,
  `name` char(50) NOT NULL,
  `address` text NOT NULL,
  `postal_code` bigint(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `f_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping_details`
--

INSERT INTO `shipping_details` (`id`, `name`, `address`, `postal_code`, `city`, `state`, `phone`, `f_id`) VALUES
(1, 'sanjeev kumar', ' 141 delhi', 110009, 'delhi', 'delhi', 9015501897, 'sanjeev'),
(2, 'sanjeev kumar', ' 141 delhi', 110009, 'delhi', 'delhi', 9015501897, 'sanjeev'),
(3, 'ajmak', ' fgadr', 5542, 'sags', 'saas', 2654478, 'ajmal'),
(4, 'ag', ' hrestr', 36533, 'dhs', 'dbs', 242, 'suri'),
(5, 'fgsg', ' sshs', 0, 'ehh', 'seg', 86621145, 'suri'),
(6, 'sdfw', ' gergr', 0, 'rege', 'eragare', 3565, 'suri'),
(7, 'dwfw', ' wdqw', 54124, 'wdc', 'adfv', 2566, 'suri'),
(8, 'gfdghd', ' ff', 65, 'rh', 'rdhd', 8855, 'dig'),
(9, 'devendra', ' Rajanukunte', 560064, 'Bangalore', 'Karnataka', 8553623673, 'dig'),
(10, 'w', ' wg', 0, 'sg', 'wg', 345, 'dig'),
(11, 'fd', ' we', 456, 'w', 'rwg', 345, 'dig'),
(12, 'ub', ' hgcvhb', 455667, 'cvb', 'gfchg', 456678, 'dig'),
(13, 'devendra', 'Rajanukunte', 560064, 'Bangalore', 'Karnataka', 8553623673, '1234'),
(14, 'devendra', 'Rajanukunte', 560064, 'Bangalore', 'Karnataka', 8553623673, '1234'),
(15, 'diganth', 'Rajanukunte', 560064, 'Bangalore', 'Karnataka', 54665434567, '12345');

-- --------------------------------------------------------

--
-- Table structure for table `subcat`
--

CREATE TABLE `subcat` (
  `subcat_id` int(4) NOT NULL,
  `parent_id` int(4) NOT NULL,
  `subcat_nm` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcat`
--

INSERT INTO `subcat` (`subcat_id`, `parent_id`, `subcat_nm`) VALUES
(57, 25, '3rd year'),
(56, 25, '2nd year'),
(55, 25, '1st year'),
(54, 27, '4th year'),
(53, 27, '3rd year'),
(52, 27, '2nd year'),
(51, 27, '1st year'),
(50, 28, '4th year'),
(48, 28, '2nd year'),
(49, 28, '3rd year'),
(44, 28, '1st year'),
(43, 29, '4th year'),
(42, 29, '3rd year'),
(41, 29, '2nd year'),
(40, 29, '1st year'),
(39, 24, '4th year'),
(38, 24, '3rd year'),
(37, 24, '2nd year'),
(36, 24, '1st year'),
(8, 4, '8th sem'),
(7, 4, '7th sem'),
(6, 3, '6th sem'),
(5, 3, '5th  sem'),
(4, 2, '4th sem'),
(1, 1, '1st sem'),
(2, 1, '2nd sem'),
(3, 2, '3rd sem'),
(58, 25, '4th year'),
(59, 26, '1st year'),
(60, 26, '2nd year'),
(61, 26, '3rd year'),
(62, 26, '4th year');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_id` int(4) NOT NULL,
  `u_fnm` varchar(35) NOT NULL,
  `u_unm` varchar(25) NOT NULL,
  `u_pwd` varchar(20) NOT NULL,
  `u_gender` varchar(7) NOT NULL,
  `u_email` varchar(35) NOT NULL,
  `u_contact` varchar(12) NOT NULL,
  `u_city` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `u_fnm`, `u_unm`, `u_pwd`, `u_gender`, `u_email`, `u_contact`, `u_city`) VALUES
(1, 'Hiren Bhaliya', 'Hiren', 'hiru', 'Male', 'hiru@gmail.com', '9925136522', 'Rajkot'),
(2, 'Shital', 'shital', 'shital', 'Female', 'shital@yahoo.com', '9985689856', 'Rajkot'),
(3, 'Lina', 'Lina123', '123', 'Female', 'lina123@gmail.com', '9456325663', 'Amreli'),
(4, 'admin', 'admin', 'admin123', 'Female', 'admin@gmail.com', '9859632561', 'Rajkot'),
(5, 'Kaushik', 'Darcy', '160160160', 'Male', 'darcy@gmail.com', '9016388880', 'Rajkot'),
(6, 'sanjeev', 'kumar', 'sanjeev', 'Male', 'sanjeevtech2@gmail.com', '9015501897', 'Ahmedabad'),
(7, 'dig', 'dig', 'dig', 'Male', 'dig@gmail.com', '9945168773', 'Ahmedabad'),
(8, 'bhaaa', 'bhav', 'baba', 'Female', 'baba@gmail.com', '78945612', 'Jamnagar'),
(9, 'suresh', 'suri', 'suri', 'Male', 'suri@gmail.com', '9448769953', 'Rajkot'),
(10, 'kruthika', 'kruthi', 'kruthi', 'Female', 'kruthi@gmail.com', '', 'Ahmedabad'),
(11, 'ajmal  ', 'ajmal', 'ajmal', 'Male', 'ajmal@gmail.com', '65646546546', 'Ahmedabad'),
(12, 'diganth', 'dig1', 'dig', 'Male', 'diganth@gmail.com', '788962155', 'Amreli'),
(13, 'teja', 'teja2', '1234', 'Male', 'teja@gmail.com', '8024522545', 'Ahmedabad'),
(14, 'srihari', 'v', '123456', 'Male', 'sri@gmail.com', '8500221368', 'Ahmedabad'),
(15, 'hari', 've', 'qwerty', 'Male', 'wsf@gmail.com', '5645123698', 'Ahmedabad'),
(16, 'diga', 'dig123', '12345', 'Male', 'dig2@gmail.com', '740669595', 'Junagadh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`con_id`);

--
-- Indexes for table `shipping_details`
--
ALTER TABLE `shipping_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcat`
--
ALTER TABLE `subcat`
  ADD PRIMARY KEY (`subcat_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `b_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `con_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `shipping_details`
--
ALTER TABLE `shipping_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `subcat`
--
ALTER TABLE `subcat`
  MODIFY `subcat_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `u_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
